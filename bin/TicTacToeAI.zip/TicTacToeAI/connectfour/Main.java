package TicTacToeAI.connectfour;

public class Main {
  public static void main(String[] args) {
    System.out.println("Connect Four");
    
    ConnectFour game = new ConnectFour();

    game.play();

  }
}
