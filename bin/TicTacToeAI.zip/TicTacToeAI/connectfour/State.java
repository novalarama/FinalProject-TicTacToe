package TicTacToeAI.connectfour;

public enum State { // to save as "State.java"
  PLAYING, DRAW, CROSS_WON, NOUGHT_WON
}
